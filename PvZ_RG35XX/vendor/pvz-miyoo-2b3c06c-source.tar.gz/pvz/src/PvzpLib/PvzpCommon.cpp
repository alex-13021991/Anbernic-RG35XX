/*
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#include "SexyAppBase.h"
#include "PvzpList.h"
#include <algorithm>
#include "PvzpDebug.h"
#include "PvzpCommon.h"
#include "../LawnApp.h"
#include "EffectSystem.h"
#include "../Resources.h"
#include "PvzpStringFile.h"
#include "../GameConstants.h"
#include "graphics/Font.h"
#include "graphics/GLImage.h"
#include "graphics/Graphics.h"
#include "graphics/ImageFont.h"
#include "graphics/MemoryImage.h"
#include "misc/PerfTimer.h"
#include "misc/SexyMatrix.h"
#include "graphics/GLInterface.h"

void Pvzp_SWTri_AddAllDrawTriFuncs()
{
	SWTri_AddDrawTriFunc(true, false, false, false, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, false, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, true, false, false, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, false, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x8888, false, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x8888, true, PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, false, false, false, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, false, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, true, false, false, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, false, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0888, false, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0888, true, PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, false, false, false, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, false, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, true, false, false, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, false, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0565, false, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0565, true, PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, false, false, false, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, false, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, false, true, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, false, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, false, true, true, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB1_BLEND1);

	SWTri_AddDrawTriFunc(true, true, false, false, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, false, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, false, true, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB1_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB0_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, false, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB0_BLEND1);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0555, false, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB1_BLEND0);
	SWTri_AddDrawTriFunc(true, true, true, true, 0x0555, true, PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB1_BLEND1);
}

intptr_t PvzpPickFromWeightedArray(const PvzpWeightedArray* theArray, int theCount)
{
	const PvzpWeightedArray* aPicked = PvzpPickArrayItemFromWeightedArray(theArray, theCount);
	if (aPicked != nullptr)
	{
		return aPicked->mItem;
	}
	if (theArray != nullptr && theCount > 0)
	{
		return theArray[0].mItem;
	}
	return 0;
}

PvzpWeightedArray* PvzpPickArrayItemFromWeightedArray(const PvzpWeightedArray* theArray, int theCount)
{
	if (theCount <= 0 || theArray == nullptr)
		return nullptr;

	int aTotalWeight = 0;
	for (int i = 0; i < theCount; i++)
	{
		aTotalWeight += theArray[i].mWeight;
	}
	if (aTotalWeight <= 0)
	{
		return (PvzpWeightedArray*)&theArray[0];
	}

	aTotalWeight = Sexy::Rand(aTotalWeight);

	for (int i = 0; i < theCount; i++)
	{
		aTotalWeight -= theArray[i].mWeight;
		if (aTotalWeight < 0)
		{
			return (PvzpWeightedArray*)&theArray[i];
		}
	}

	return (PvzpWeightedArray*)&theArray[theCount - 1];
}

PvzpWeightedGridArray* PvzpPickFromWeightedGridArray(const PvzpWeightedGridArray* theArray, int theCount)
{
	if (theCount <= 0 || theArray == nullptr)
		return nullptr;

	int aTotalWeight = 0;
	for (int i = 0; i < theCount; i++)
	{
		aTotalWeight += theArray[i].mWeight;
	}
	if (aTotalWeight <= 0)
	{
		return (PvzpWeightedGridArray*)&theArray[0];
	}

	aTotalWeight = Sexy::Rand(aTotalWeight);

	for (int i = 0; i < theCount; i++)
	{
		aTotalWeight -= theArray[i].mWeight;
		if (aTotalWeight < 0)
		{
			return (PvzpWeightedGridArray*)&theArray[i];
		}
	}

	return (PvzpWeightedGridArray*)&theArray[theCount - 1];
}

float PvzpCalcSmoothWeight(float aWeight, float aLastPicked, float aSecondLastPicked)
{
	if (aWeight < 1E-6f)
	{
		return 0.0f;
	}

	float aExpectedLength1 = 1.0f / aWeight;								// expected value of theLastPicked
	float aExpectedLength2 = aExpectedLength1 * 2.0f;						// expected value of theSecondLastPicked
	float aAdvancedLength1 = aLastPicked + 1.0f - aExpectedLength1;			// rounds ahead of the expected value of theLastPicked
	float aAdvancedLength2 = aSecondLastPicked + 1.0f - aExpectedLength2;	// rounds ahead of the expected value of theSecondLastPicked
	float aFactor1 = 1.0f + aAdvancedLength1 / aExpectedLength1 * 2.0f;		// = aWeight * aLastPicked * 2 + aWeight * 2 - 1
	float aFactor2 = 1.0f + aAdvancedLength2 / aExpectedLength2 * 2.0f;		// = aSecondLastPicked * aWeight + aWeight - 1
	float aFactorFinal = std::clamp(aFactor1 * 0.75f + aFactor2 * 0.25f, 0.01f, 100.0f);
	return aWeight * aFactorFinal;
}

int PvzpPickFromSmoothArray(PvzpSmoothArray* theArray, int theCount)
{
	if (theCount <= 0 || theArray == nullptr)
		return 0;

	float aTotalWeight = 0.0f;
	for (int i = 0; i < theCount; i++)
	{
		aTotalWeight += theArray[i].mWeight;
	}
	if (aTotalWeight <= 0.0f)
	{
		return theArray[0].mItem;
	}

	float aNormalizeFactor = 1.0f / aTotalWeight;
	float aTotalAdjustedWeight = 0.0f;
	for (int j = 0; j < theCount; j++)
	{
		aTotalAdjustedWeight += PvzpCalcSmoothWeight(theArray[j].mWeight * aNormalizeFactor, theArray[j].mLastPicked, theArray[j].mSecondLastPicked);
	}
	if (aTotalAdjustedWeight <= 0.0f)
	{
		return theArray[0].mItem;
	}

	float aRandWeight = Rand(aTotalAdjustedWeight);
	float aAccumulatedWeight = 0.0f;
	int k;
	for (k = 0; k < theCount - 1; k++)
	{
		aAccumulatedWeight += PvzpCalcSmoothWeight(theArray[k].mWeight * aNormalizeFactor, theArray[k].mLastPicked, theArray[k].mSecondLastPicked);
		if (aRandWeight <= aAccumulatedWeight)
		{
			break;
		}
	}

	PvzpUpdateSmoothArrayPick(theArray, theCount, k);
	return theArray[k].mItem;
}

void PvzpUpdateSmoothArrayPick(PvzpSmoothArray* theArray, int theCount, int thePickIndex)
{
	for (int i = 0; i < theCount; i++)
	{
		if (theArray[i].mWeight > 0.0f)
		{
			theArray[i].mLastPicked += 1.0f;
			theArray[i].mSecondLastPicked += 1.0f;
		}
	}

	theArray[thePickIndex].mSecondLastPicked = theArray[thePickIndex].mLastPicked;
	theArray[thePickIndex].mLastPicked = 0.0f;
}

float PvzpCurveQuad(float theTime)
{
	return theTime * theTime;
}

float PvzpCurveInvQuad(float theTime)
{
	return 2 * theTime - theTime * theTime;
}

float PvzpCurveS(float theTime)
{
	return 3 * theTime * theTime - 2 * theTime * theTime * theTime;
}

float PvzpCurveInvQuadS(float theTime)
{
	//float aVal = 2 * (theTime - theTime * theTime);
	//return theTime <= 0.5 ? aVal : 1 - aVal;
	if (theTime <= 0.5f)
	{
		return PvzpCurveInvQuad(theTime * 2.0f) * 0.5f;
	}
	return PvzpCurveQuad((theTime - 0.5f) * 2.0f) * 0.5f + 0.5f;
}

float PvzpCurveBounce(float theTime)
{
	return 1 - fabs(2 * theTime - 1);
}

float PvzpCurveQuadS(float theTime)
{
	if (theTime <= 0.5f)
	{
		return PvzpCurveQuad(theTime * 2.0f) * 0.5f;
	}
	return PvzpCurveInvQuad((theTime - 0.5f) * 2.0f) * 0.5f + 0.5f;
}

float PvzpCurveCubic(float theTime)
{
	return theTime * theTime * theTime;
}

float PvzpCurveInvCubic(float theTime)
{
	return (theTime - 1.0f) * (theTime - 1.0f) * (theTime - 1.0f) + 1.0f;
}

float PvzpCurveCubicS(float theTime)
{
	if (theTime <= 0.5f)
	{
		return PvzpCurveCubic(theTime * 2.0f) * 0.5f;
	}
	return PvzpCurveInvCubic((theTime - 0.5f) * 2.0f) * 0.5f + 0.5f;
}

float PvzpCurvePoly(float theTime, float thePoly)
{
	return static_cast<float>(pow(theTime, thePoly));
}

float PvzpCurveInvPoly(float theTime, float thePoly)
{
	return static_cast<float>(pow(theTime - 1.0f, thePoly)) + 1.0f;
}

float PvzpCurvePolyS(float theTime, float thePoly)
{
	if (theTime <= 0.5f)
	{
		return PvzpCurvePoly(theTime * 2.0f, thePoly) * 0.5f;
	}
	return PvzpCurveInvPoly((theTime - 0.5f) * 2.0f, thePoly) * 0.5f + 0.5f;
}

float PvzpCurveCircle(float theTime)
{
	if (theTime > 1 - 1E-6f)
	{
		return 1.0f;
	}
	return 1.0f - static_cast<float>(sqrt(1.0f - theTime * theTime));
}

float PvzpCurveInvCircle(float theTime)
{
	if (theTime < 1E-06f)
	{
		return 0.0f;
	}
	return static_cast<float>(sqrt(1.0f - (theTime - 1.0f) * (theTime - 1.0f)));
}

float PvzpCurveEvaluateClamped(float theTime, float thePositionStart, float thePositionEnd, PvzpCurves theCurve)
{
	if (theTime <= 0.0f)
	{
		return thePositionStart;
	}

	if (theTime >= 1.0f)
	{
		if (theCurve == PvzpCurves::CURVE_BOUNCE ||
			theCurve == PvzpCurves::CURVE_BOUNCE_FAST_MIDDLE ||
			theCurve == PvzpCurves::CURVE_BOUNCE_SLOW_MIDDLE ||
			theCurve == PvzpCurves::CURVE_SIN_WAVE ||
			theCurve == PvzpCurves::CURVE_EASE_SIN_WAVE)
		{
			return thePositionStart;
		}
		else
		{
			return thePositionEnd;
		}
	}

	return PvzpCurveEvaluate(theTime, thePositionStart, thePositionEnd, theCurve);
}

float PvzpAnimateCurveFloatTime(float theTimeStart, float theTimeEnd, float theTimeAge, float thePositionStart, float thePositionEnd, PvzpCurves theCurve)
{
	if (theTimeEnd == theTimeStart)
		return thePositionEnd;

	float aWarpedAge = (theTimeAge - theTimeStart) / (theTimeEnd - theTimeStart);
	return PvzpCurveEvaluateClamped(aWarpedAge, thePositionStart, thePositionEnd, theCurve);
}

float PvzpAnimateCurveFloat(int theTimeStart, int theTimeEnd, int theTimeAge, float thePositionStart, float thePositionEnd, PvzpCurves theCurve)
{
	if (theTimeEnd == theTimeStart)
		return thePositionEnd;

	float aWarpedAge = (theTimeAge - theTimeStart) / static_cast<float>(theTimeEnd - theTimeStart);
	return PvzpCurveEvaluateClamped(aWarpedAge, thePositionStart, thePositionEnd, theCurve);
}

int PvzpAnimateCurve(int theTimeStart, int theTimeEnd, int theTimeAge, int thePositionStart, int thePositionEnd, PvzpCurves theCurve)
{
	return FloatRoundToInt(PvzpAnimateCurveFloat(theTimeStart, theTimeEnd, theTimeAge, thePositionStart, thePositionEnd, theCurve));
}

int RandRangeInt(int theMin, int theMax)
{
	PVZP_ASSERT(theMin <= theMax);
	return Rand(theMax - theMin + 1) + theMin;
}

float RandRangeFloat(float theMin, float theMax)
{
	PVZP_ASSERT(theMin <= theMax);
	return Rand(theMax - theMin) + theMin;
}

void PvzpDrawString(Graphics* g, std::string_view theText, int thePosX, int thePosY, _Font* theFont, const Color& theColor, DrawStringJustification theJustification)
{
	std::string_view aFinalString = PvzpStringTranslate(theText);

	int aPosX = thePosX;
	if (theJustification == DrawStringJustification::DS_ALIGN_RIGHT || theJustification == DrawStringJustification::DS_ALIGN_RIGHT_VERTICAL_MIDDLE)
	{
		aPosX -= theFont->StringWidth(aFinalString);
	}
	else if (theJustification == DrawStringJustification::DS_ALIGN_CENTER || theJustification == DrawStringJustification::DS_ALIGN_CENTER_VERTICAL_MIDDLE)
	{
		aPosX -= theFont->StringWidth(aFinalString) / 2;
	}

	theFont->DrawString(g, aPosX, thePosY, aFinalString, theColor, g->mClipRect);
}

void PvzpDrawImageCelScaled(Graphics* g, Image* theImageStrip, int thePosX, int thePosY, int theCelCol, int theCelRow, float theScaleX, float theScaleY)
{
	PVZP_ASSERT(theCelCol >= 0 && theCelCol < theImageStrip->mNumCols);
	PVZP_ASSERT(theCelRow >= 0 && theCelRow < theImageStrip->mNumRows);

	int aCelWidth = theImageStrip->GetCelWidth();
	int aCelHeight = theImageStrip->GetCelHeight();
	Rect aSrcRect(aCelWidth * theCelCol, aCelHeight * theCelRow, aCelWidth, aCelHeight);
	Rect aDestRect(thePosX, thePosY, FloatRoundToInt(aCelWidth * theScaleX), FloatRoundToInt(aCelHeight * theScaleY));
	g->DrawImage(theImageStrip, aDestRect, aSrcRect);
}

static const int POOL_SIZE = 4096;
static RenderCommand gRenderCommandPool[POOL_SIZE];
static RenderCommand* gRenderTail[256];
static RenderCommand* gRenderHead[256];

void PvzpDrawStringMatrix(Graphics* g, const _Font* theFont, const SexyMatrix3& theMatrix, std::string_view theString, const Color& theColor)
{
	std::string_view aFinalString = PvzpStringTranslate(theString);

	memset(gRenderTail, 0, sizeof(gRenderTail));
	memset(gRenderHead, 0, sizeof(gRenderHead));
	ImageFont* aFont = reinterpret_cast<ImageFont*>(const_cast<_Font*>(theFont));
	if (!aFont->mFontData->mInitialized)
		return;

	aFont->Prepare();
	int aCurXPos = 0;
	int aCurPoolIdx = 0;
	size_t aDecodeOffset = 0;
	char32_t aCurRawChar = 0;
	char32_t aNextRawChar = 0;
	bool aHasCur = UTF8DecodeNext(aFinalString, aDecodeOffset, aCurRawChar);
	while (aHasCur)
	{
		const bool aHasNext = UTF8DecodeNext(aFinalString, aDecodeOffset, aNextRawChar);
		const char32_t aChar = aFont->GetMappedChar(aCurRawChar);
		const char32_t aNextChar = aHasNext ? aFont->GetMappedChar(aNextRawChar) : 0;

		int aMaxXPos = aCurXPos;
		for (auto aKernItr = aFont->mActiveLayerList.begin(); aKernItr != aFont->mActiveLayerList.end(); aKernItr++)
		{
			FontLayer* aLayer = aKernItr->mBaseFontLayer;
			CharData* aCharData = aLayer->GetCharData(aChar);
			auto aRectItr = aKernItr->mScaledCharImageRects.find(aChar);
			if (aRectItr == aKernItr->mScaledCharImageRects.end())
				continue;
			double aScale = aFont->mScale;
			int aLayerPointSize = aLayer->mPointSize;
			if (aLayerPointSize)
			{
				aScale *= static_cast<float>(aFont->mPointSize) / static_cast<float>(aLayerPointSize);
			}

			int anImageX, anImageY, aCharWidth, aSpacing;
			if (aScale == 1.0f)
			{
				anImageX = aCharData->mOffset.mX + aLayer->mOffset.mX + aCurXPos;
				anImageY = aCharData->mOffset.mY + aLayer->mOffset.mY - aLayer->mAscent;
				aCharWidth = aCharData->mWidth;

				if (aNextChar == 0)
				{
					aSpacing = 0;
				}
				else
				{
					aSpacing = aLayer->mSpacing;

					//aSpacing += aCharData->mKerningOffsets[aNextChar];
					auto anItr = aCharData->mKerningOffsets.find(aNextChar);
					if (anItr != aCharData->mKerningOffsets.end())
					{
						aSpacing += anItr->second;
					}
				}
			}
			else
			{
				anImageX = aCurXPos + floor((aCharData->mOffset.mX + aLayer->mOffset.mX) * aScale);
				anImageY = -floor((aLayer->mAscent - aLayer->mOffset.mY - aCharData->mOffset.mY) * aScale);
				aCharWidth = aCharData->mWidth * aScale;

				if (aNextChar == 0)
				{
					aSpacing = 0;
				}
				else
				{
					aSpacing = aLayer->mSpacing;

					//aSpacing += aCharData->mKerningOffsets[aNextChar] * aScale;
					auto anItr = aCharData->mKerningOffsets.find(aNextChar);
					if (anItr != aCharData->mKerningOffsets.end())
					{
						aSpacing += anItr->second * aScale;
					}
				}
			}

			Color aColor;
			aColor.mRed = std::min(aLayer->mColorAdd.mRed + theColor.mRed * aLayer->mColorMult.mRed / 255, 255);
			aColor.mGreen = std::min(aLayer->mColorAdd.mGreen + theColor.mGreen * aLayer->mColorMult.mGreen / 255, 255);
			aColor.mBlue = std::min(aLayer->mColorAdd.mBlue + theColor.mBlue * aLayer->mColorMult.mBlue / 255, 255);
			aColor.mAlpha = std::min(aLayer->mColorAdd.mAlpha + theColor.mAlpha * aLayer->mColorMult.mAlpha / 255, 255);
			int anOrder = aCharData->mOrder + aLayer->mBaseOrder;

			if (aCurPoolIdx >= POOL_SIZE)
				break;

			RenderCommand* aRenderCommand = &gRenderCommandPool[aCurPoolIdx++];
			aRenderCommand->mImage = aKernItr->mScaledImage;
			aRenderCommand->mColor = aColor;
			aRenderCommand->mDest[0] = anImageX;
			aRenderCommand->mDest[1] = anImageY;
			aRenderCommand->mSrc[0] = aRectItr->second.mX;
			aRenderCommand->mSrc[1] = aRectItr->second.mY;
			aRenderCommand->mSrc[2] = aRectItr->second.mWidth;
			aRenderCommand->mSrc[3] = aRectItr->second.mHeight;
			aRenderCommand->mMode = aLayer->mDrawMode;
			aRenderCommand->mUseAlphaCorrection = aLayer->mUseAlphaCorrection;
			aRenderCommand->mNext = nullptr;

			int anOrderIdx = std::clamp(anOrder + 128, 0, 255);
			if (gRenderTail[anOrderIdx])
			{
				gRenderTail[anOrderIdx]->mNext = aRenderCommand;
				gRenderTail[anOrderIdx] = aRenderCommand;
			}
			else
			{
				gRenderHead[anOrderIdx] = aRenderCommand;
				gRenderTail[anOrderIdx] = aRenderCommand;
			}

			//aCurXPos += aSpacing + aCharWidth;
			//if (aCurXPos > aMaxXPos)
			//{
			//	aMaxXPos = aCurXPos;
			//}
			aMaxXPos = std::max(aMaxXPos, aCurXPos + aSpacing + aCharWidth);
		}

		aCurXPos = aMaxXPos;
		aCurRawChar = aNextRawChar;
		aHasCur = aHasNext;
	}

	for (int aPoolIdx = 0; aPoolIdx < 256; aPoolIdx++)
	{
		RenderCommand* aRenderCommand = gRenderHead[aPoolIdx];

		while (aRenderCommand)
		{
			int aDrawMode = g->GetDrawMode();
			if (aRenderCommand->mMode != -1)
			{
				aDrawMode = aRenderCommand->mMode;
			}

			if (aRenderCommand->mImage)
			{
				Rect aSrcRect(aRenderCommand->mSrc[0], aRenderCommand->mSrc[1], aRenderCommand->mSrc[2], aRenderCommand->mSrc[3]);
				SexyTransform2D aTransform;
				float aPosX = aSrcRect.mWidth * 0.5f + aRenderCommand->mDest[0];
				float aPosY = aSrcRect.mHeight * 0.5f + aRenderCommand->mDest[1];
				SexyMatrix3Translation(aTransform, aPosX, aPosY);
				SexyMatrix3Multiply(aTransform, theMatrix, aTransform);
				PvzpBltMatrix(g, aRenderCommand->mImage, aTransform, g->mClipRect, aRenderCommand->mColor, aDrawMode, aSrcRect);
			}

			aRenderCommand = aRenderCommand->mNext;
		}
	}
}

void PvzpDrawImageCelF(Graphics* g, Image* theImageStrip, float thePosX, float thePosY, int theCelCol, int theCelRow)
{
	PVZP_ASSERT(theCelCol >= 0 && theCelCol < theImageStrip->mNumCols);
	PVZP_ASSERT(theCelRow >= 0 && theCelRow < theImageStrip->mNumRows);

	int aCelWidth = theImageStrip->GetCelWidth();
	int aCelHeight = theImageStrip->GetCelHeight();
	Rect theSrcRect(aCelWidth * theCelCol, aCelHeight * theCelRow, aCelWidth, aCelHeight);
	g->DrawImageF(theImageStrip, thePosX, thePosY, theSrcRect);
}

void SexyMatrix3Translation(SexyMatrix3& m, float x, float y)
{
	m.m02 += x;
	m.m12 += y;
}

void PvzpScaleTransformMatrix(SexyMatrix3& m, float x, float y, float theScaleX, float theScaleY)
{
	m.m00 = theScaleX;
	m.m10 = 0.0f;
	m.m20 = 0.0f;
	m.m01 = 0.0f;
	m.m11 = theScaleY;
	m.m21 = 0.0f;
	m.m02 = x;
	m.m12 = y;
	m.m22 = 1.0f;
}

void PvzpScaleRotateTransformMatrix(SexyMatrix3& m, float x, float y, float rad, float theScaleX, float theScaleY)
{
	m.m00 = cos(rad) * theScaleX;
	m.m10 = -sin(rad) * theScaleX;
	m.m20 = 0.0f;
	m.m01 = sin(rad) * theScaleY;
	m.m11 = cos(rad) * theScaleY;
	m.m21 = 0.0f;
	m.m02 = x;
	m.m12 = y;
	m.m22 = 1.0f;
}

void SexyMatrix3ExtractScale(const SexyMatrix3& m, float& theScaleX, float& theScaleY)
{
	float kx = atan2(m.m00, m.m10);
	if (abs(kx) < PI / 4 || abs(kx) > 4 * PI / 3)
	{
		theScaleX = m.m10 / cos(kx);
	}
	else
	{
		theScaleX = m.m00 / sin(kx);
	}

	float ky = atan2(m.m11, m.m01);
	if (abs(ky) < PI / 4 || abs(ky) > 4 * PI / 3)
	{
		theScaleY = m.m01 / cos(ky);
	}
	else
	{
		theScaleY = m.m11 / sin(ky);
	}
}

void PvzpMarkImageForSanding(Image* theImage)
{
	((MemoryImage*)theImage)->mRenderFlags |= RENDERIMAGEFLAG_SANDING;
}

void PvzpSandImageIfNeeded(Image* theImage)
{
	if (!gSexyAppBase || !gSexyAppBase->Is3DAccelerated())
		return;

	MemoryImage* aImage = (MemoryImage*)theImage;
	/*if (TestBit(aImage->mRenderFlags, RENDERIMAGEFLAG_SANDING))*/ // UB shift by a billion
	if (aImage->mRenderFlags & RENDERIMAGEFLAG_SANDING)
	{
		FixPixelsOnAlphaEdgeForBlending(theImage);
		((MemoryImage*)theImage)->mRenderFlags &= ~RENDERIMAGEFLAG_SANDING; // Unset the sanding flag
		//SetBit((unsigned int&)aImage->mRenderFlags, RENDERIMAGEFLAG_SANDING, false);  // Also UB!?!
	}
}

void PvzpBltMatrix(Graphics* g, Image* theImage, const SexyMatrix3& theTransform, const Rect& theClipRect, const Color& theColor, int theDrawMode, const Rect& theSrcRect)
{
	if (theImage == nullptr || g == nullptr || g->mDestImage == nullptr)
		return;
	uintptr_t aVal = reinterpret_cast<uintptr_t>(theImage);
	if ((aVal % 4 != 0) || aVal < 0x10000)
		return;
	if (theImage->mWidth <= 0 || theImage->mWidth > 16384 || theImage->mHeight <= 0 || theImage->mHeight > 16384)
		return;

	float aOffsetX = 0.0f;
	float aOffsetY = 0.0f;
	if (gSexyAppBase->Is3DAccelerated())
	{
		aOffsetX -= 0.5f;
		aOffsetY -= 0.5f;
	}
	else if (theDrawMode == Graphics::DRAWMODE_ADDITIVE)
	{
		gPvzpTriangleDrawAdditive = true;
	}

	PvzpSandImageIfNeeded(theImage);

	if (!gSexyAppBase->Is3DAccelerated() &&
		std::abs(theTransform.m01) < 1e-4f && std::abs(theTransform.m10) < 1e-4f &&
		theTransform.m00 > 0.0f && theTransform.m11 > 0.0f)
	{
		float aScaleX = theTransform.m00;
		float aScaleY = theTransform.m11;
		int aPosX = FloatRoundToInt(theTransform.m02 - g->mTransX - aScaleX * theSrcRect.mWidth * 0.5f);
		int aPosY = FloatRoundToInt(theTransform.m12 - g->mTransY - aScaleY * theSrcRect.mHeight * 0.5f);
		int aWidth = FloatRoundToInt(aScaleX * theSrcRect.mWidth);
		int aHeight = FloatRoundToInt(aScaleY * theSrcRect.mHeight);

		int aOldMode = g->GetDrawMode();
		g->SetDrawMode(theDrawMode);
		Rect aOldClipRect = g->mClipRect;
		g->mClipRect = theClipRect;

		Color aOldColor = g->GetColor();
		bool aOldColorize = g->GetColorizeImages();
		if (theColor != Color::White)
		{
			g->SetColor(theColor);
			g->SetColorizeImages(true);
		}

		bool aOldFastStretch = g->GetFastStretch();
		g->SetFastStretch(true);

		if (FloatApproxEqual(aScaleX, 1.0f) && FloatApproxEqual(aScaleY, 1.0f))
			g->DrawImage(theImage, aPosX, aPosY, theSrcRect);
		else
		{
			Rect aDestRect(aPosX, aPosY, aWidth, aHeight);
			g->DrawImage(theImage, aDestRect, theSrcRect);
		}

		g->SetFastStretch(aOldFastStretch);

		if (theColor != Color::White)
		{
			g->SetColor(aOldColor);
			g->SetColorizeImages(aOldColorize);
		}

		g->SetDrawMode(aOldMode);
		g->mClipRect = aOldClipRect;
		gPvzpTriangleDrawAdditive = false;
		return;
	}

	if (!gSexyAppBase->Is3DAccelerated() &&
		FloatApproxEqual(theTransform.m00, 0.0f) && FloatApproxEqual(theTransform.m11, 0.0f) &&
		FloatApproxEqual(std::abs(theTransform.m01), 1.0f) && FloatApproxEqual(std::abs(theTransform.m10), 1.0f))
	{
		MemoryImage* aDstImage = dynamic_cast<MemoryImage*>(g->mDestImage);
		MemoryImage* aSrcImage = dynamic_cast<MemoryImage*>(theImage);
		if (aDstImage && aSrcImage && aSrcImage->mColorTable == nullptr && aDstImage->mPixelFormat == 0 && aSrcImage->mPixelFormat == 0)
		{
			uint32_t* pDstBits = aDstImage->GetBits();
			uint32_t* pSrcBits = aSrcImage->GetBits();
			if (pDstBits && pSrcBits)
			{
				int aSrcW = theSrcRect.mWidth;
				int aSrcH = theSrcRect.mHeight;
				int aDestW = aSrcH;
				int aDestH = aSrcW;
				int aDestX = FloatRoundToInt(theTransform.m02 - aDestW * 0.5f);
				int aDestY = FloatRoundToInt(theTransform.m12 - aDestH * 0.5f);

				Rect aDestRect(aDestX, aDestY, aDestW, aDestH);
				Rect aClip = aDestRect.Intersection(theClipRect);
				aClip = aClip.Intersection(Rect(0, 0, g->mDestImage->mWidth, g->mDestImage->mHeight));
				if (aClip.mWidth <= 0 || aClip.mHeight <= 0)
				{
					gPvzpTriangleDrawAdditive = false;
					return;
				}

				int dstPitch = aDstImage->mWidth;
				int srcPitch = aSrcImage->mWidth;
				bool hasColor = (theColor != Color::White);
				uint32_t ca = theColor.mAlpha;
				uint32_t cr = theColor.mRed;
				uint32_t cg = theColor.mGreen;
				uint32_t cb = theColor.mBlue;

				if (theDrawMode == Graphics::DRAWMODE_NORMAL)
				{
					if (!hasColor)
					{
						for (int y = aClip.mY; y < aClip.mY + aClip.mHeight; ++y)
						{
							int dest_rel_y = y - aDestY;
							int sx = (theTransform.m10 < 0.0f) ? (aSrcW - 1 - dest_rel_y) : dest_rel_y;
							int srcPixelX = theSrcRect.mX + sx;
							uint32_t* pDst = pDstBits + y * dstPitch + aClip.mX;

							for (int x = aClip.mX; x < aClip.mX + aClip.mWidth; ++x, ++pDst)
							{
								int dest_rel_x = x - aDestX;
								int sy = (theTransform.m01 > 0.0f) ? dest_rel_x : (aSrcH - 1 - dest_rel_x);
								int srcPixelY = theSrcRect.mY + sy;
								uint32_t src = pSrcBits[srcPixelY * srcPitch + srcPixelX];
								uint32_t a = src >> 24;
								if (a == 0)
									continue;
								if (a == 255)
								{
									*pDst = src;
								}
								else
								{
									uint32_t dest = *pDst;
									uint32_t aDestAlpha = dest >> 24;
									uint32_t aNewDestAlpha = aDestAlpha + ((255 - aDestAlpha) * a) / 255;
									if (aNewDestAlpha > 0)
									{
										uint32_t blend_a = 255 * a / aNewDestAlpha;
										int oma = 256 - blend_a;
										*pDst = (aNewDestAlpha << 24) |
											((((dest & 0xFF00FF) * oma >> 8) + ((src & 0xFF00FF) * blend_a >> 8)) & 0xFF00FF) |
											((((dest & 0x00FF00) * oma >> 8) + ((src & 0x00FF00) * blend_a >> 8)) & 0x00FF00);
									}
								}
							}
						}
					}
					else
					{
						for (int y = aClip.mY; y < aClip.mY + aClip.mHeight; ++y)
						{
							int dest_rel_y = y - aDestY;
							int sx = (theTransform.m10 < 0.0f) ? (aSrcW - 1 - dest_rel_y) : dest_rel_y;
							int srcPixelX = theSrcRect.mX + sx;
							uint32_t* pDst = pDstBits + y * dstPitch + aClip.mX;

							for (int x = aClip.mX; x < aClip.mX + aClip.mWidth; ++x, ++pDst)
							{
								int dest_rel_x = x - aDestX;
								int sy = (theTransform.m01 > 0.0f) ? dest_rel_x : (aSrcH - 1 - dest_rel_x);
								int srcPixelY = theSrcRect.mY + sy;
								uint32_t src = pSrcBits[srcPixelY * srcPitch + srcPixelX];
								uint32_t srcA = src >> 24;
								if (srcA == 0)
									continue;
								uint32_t a = (srcA * ca) / 255;
								if (a == 0)
									continue;

								uint32_t sr = (((src >> 16) & 0xFF) * cr) / 255;
								uint32_t sg = (((src >> 8) & 0xFF) * cg) / 255;
								uint32_t sb = ((src & 0xFF) * cb) / 255;
								uint32_t modSrc = (a << 24) | (sr << 16) | (sg << 8) | sb;

								if (a == 255)
								{
									*pDst = modSrc;
								}
								else
								{
									uint32_t dest = *pDst;
									uint32_t aDestAlpha = dest >> 24;
									uint32_t aNewDestAlpha = aDestAlpha + ((255 - aDestAlpha) * a) / 255;
									if (aNewDestAlpha > 0)
									{
										uint32_t blend_a = 255 * a / aNewDestAlpha;
										int oma = 256 - blend_a;
										*pDst = (aNewDestAlpha << 24) |
											((((dest & 0xFF00FF) * oma >> 8) + ((modSrc & 0xFF00FF) * blend_a >> 8)) & 0xFF00FF) |
											((((dest & 0x00FF00) * oma >> 8) + ((modSrc & 0x00FF00) * blend_a >> 8)) & 0x00FF00);
									}
								}
							}
						}
					}
				}
				else if (theDrawMode == Graphics::DRAWMODE_ADDITIVE)
				{
					for (int y = aClip.mY; y < aClip.mY + aClip.mHeight; ++y)
					{
						int dest_rel_y = y - aDestY;
						int sx = (theTransform.m10 < 0.0f) ? (aSrcW - 1 - dest_rel_y) : dest_rel_y;
						int srcPixelX = theSrcRect.mX + sx;
						uint32_t* pDst = pDstBits + y * dstPitch + aClip.mX;

						for (int x = aClip.mX; x < aClip.mX + aClip.mWidth; ++x, ++pDst)
						{
							int dest_rel_x = x - aDestX;
							int sy = (theTransform.m01 > 0.0f) ? dest_rel_x : (aSrcH - 1 - dest_rel_x);
							int srcPixelY = theSrcRect.mY + sy;
							uint32_t src = pSrcBits[srcPixelY * srcPitch + srcPixelX];
							uint32_t srcA = src >> 24;
							if (srcA == 0)
								continue;

							uint32_t a = hasColor ? ((srcA * ca) / 255) : srcA;
							if (a == 0)
								continue;

							uint32_t sr = hasColor ? ((((src >> 16) & 0xFF) * cr) / 255) : ((src >> 16) & 0xFF);
							uint32_t sg = hasColor ? ((((src >> 8) & 0xFF) * cg) / 255) : ((src >> 8) & 0xFF);
							uint32_t sb = hasColor ? (((src & 0xFF) * cb) / 255) : (src & 0xFF);

							uint32_t dest = *pDst;
							uint32_t dr = (dest >> 16) & 0xFF;
							uint32_t dg = (dest >> 8) & 0xFF;
							uint32_t db = dest & 0xFF;

							uint32_t r = std::min(255U, dr + ((sr * a) >> 8));
							uint32_t g = std::min(255U, dg + ((sg * a) >> 8));
							uint32_t b = std::min(255U, db + ((sb * a) >> 8));

							*pDst = (dest & 0xFF000000) | (r << 16) | (g << 8) | b;
						}
					}
				}

				theImage->mDrawn = true;
				aDstImage->BitsChanged();
				gPvzpTriangleDrawAdditive = false;
				return;
			}
		}
	}

	if (theClipRect.mX != 0 || theClipRect.mY != 0 || theClipRect.mWidth != BOARD_WIDTH || theClipRect.mHeight != BOARD_HEIGHT)
	{
		g->mDestImage->BltMatrix(theImage, aOffsetX, aOffsetY, theTransform, theClipRect, theColor, theDrawMode, theSrcRect, g->mLinearBlend);
	}
	else if (GLImage::Check3D(g->mDestImage))
	{
		theImage->mDrawn = true;
		GLInterface* aInterface = ((GLImage*)g->mDestImage)->mGLInterface;
		aInterface->BltTransformed(theImage, nullptr, theColor, theDrawMode, theSrcRect, theTransform, g->mLinearBlend, aOffsetX, aOffsetY, true);
	}
	else
	{
		Rect aBufFixClipRect(0, 0, BOARD_WIDTH + 1, BOARD_HEIGHT + 1);
		if (g->mDestImage != nullptr)
		{
			aBufFixClipRect = aBufFixClipRect.Intersection(Rect(0, 0, g->mDestImage->mWidth, g->mDestImage->mHeight));
		}
		g->mDestImage->BltMatrix(theImage, aOffsetX, aOffsetY, theTransform, aBufFixClipRect, theColor, theDrawMode, theSrcRect, g->mLinearBlend);
	}

	gPvzpTriangleDrawAdditive = false;
}

void PvzpDrawImageCelCenterScaledF(Graphics* g, Image* theImageStrip, float thePosX, float thePosY, int theCelCol, float theScaleX, float theScaleY)
{
	PVZP_ASSERT(theCelCol >= 0 && theCelCol < theImageStrip->mNumCols);

	int aCelWidth = theImageStrip->GetCelWidth();
	int aCelHeight = theImageStrip->GetCelHeight();
	Rect aSrcRect(aCelWidth * theCelCol, 0, aCelWidth, aCelHeight);
	if (theScaleX == 1.0f && theScaleY == 1.0f)
	{
		g->DrawImageF(theImageStrip, thePosX, thePosY, aSrcRect);
		return;
	}

	if (!gSexyAppBase->Is3DAccelerated() && theScaleX > 0.0f && theScaleY > 0.0f)
	{
		PvzpSandImageIfNeeded(theImageStrip);
		int aWidth = FloatRoundToInt(theScaleX * aCelWidth);
		int aHeight = FloatRoundToInt(theScaleY * aCelHeight);
		int aPosX = FloatRoundToInt(thePosX + aCelWidth * 0.5f - aWidth * 0.5f);
		int aPosY = FloatRoundToInt(thePosY + aCelHeight * 0.5f - aHeight * 0.5f);
		Rect aDestRect(aPosX, aPosY, aWidth, aHeight);

		bool aOldFastStretch = g->GetFastStretch();
		g->SetFastStretch(true);
		g->DrawImage(theImageStrip, aDestRect, aSrcRect);
		g->SetFastStretch(aOldFastStretch);
		return;
	}

	float aTransX = aCelWidth * 0.5f + thePosX + g->mTransX;
	float aTransY = aCelHeight * 0.5f + thePosY + g->mTransY;

	SexyMatrix3 aTransform;
	aTransform.m00 = theScaleX;
	aTransform.m10 = 0.0f;
	aTransform.m20 = 0.0f;
	aTransform.m01 = 0.0f;
	aTransform.m11 = theScaleY;
	aTransform.m21 = 0.0f;
	aTransform.m02 = aTransX;
	aTransform.m12 = aTransY;
	aTransform.m22 = 1.0f;

	const Color& aColor = g->mColorizeImages ? g->mColor : Color::White;
	PvzpBltMatrix(g, theImageStrip, aTransform, g->mClipRect, aColor, g->mDrawMode, aSrcRect);
}

void PvzpDrawImageCelScaledF(Graphics* g, Image* theImageStrip, float thePosX, float thePosY, int theCelCol, int theCelRow, float theScaleX, float theScaleY)
{
	//(void)theCelRow;
	PVZP_ASSERT(theCelCol >= 0 && theCelCol < theImageStrip->mNumCols);

	int aCelWidth = theImageStrip->GetCelWidth();
	int aCelHeight = theImageStrip->GetCelHeight();
	Rect aSrcRect(aCelWidth * theCelCol, aCelHeight * theCelRow, aCelWidth, aCelHeight);
	if (theScaleX == 1.0f && theScaleY == 1.0f)
	{
		g->DrawImageF(theImageStrip, thePosX, thePosY, aSrcRect);
		return;
	}

	float aTransX = aCelWidth * 0.5f * theScaleX + thePosX + g->mTransX;
	float aTransY = aCelHeight * 0.5f * theScaleY + thePosY + g->mTransY;

	SexyMatrix3 aTransform;
	aTransform.m00 = theScaleX;
	aTransform.m10 = 0.0f;
	aTransform.m20 = 0.0f;
	aTransform.m01 = 0.0f;
	aTransform.m11 = theScaleY;
	aTransform.m21 = 0.0f;
	aTransform.m02 = aTransX;
	aTransform.m12 = aTransY;
	aTransform.m22 = 1.0f;

	const Color& aColor = g->mColorizeImages ? g->mColor : Color::White;
	PvzpBltMatrix(g, theImageStrip, aTransform, g->mClipRect, aColor, g->mDrawMode, aSrcRect);
}

void PvzpDrawImageScaledF(Graphics* g, Image* theImage, float thePosX, float thePosY, float theScaleX, float theScaleY)
{
	if (!theImage)
		return;

	if (theScaleX == 1.0f && theScaleY == 1.0f)
	{
		g->DrawImageF(theImage, thePosX, thePosY);
		return;
	}

	Rect aSrcRect(0, 0, theImage->mWidth, theImage->mHeight);
	float aTransX = theImage->mWidth * 0.5f * theScaleX + thePosX + g->mTransX;
	float aTransY = theImage->mHeight * 0.5f * theScaleY + thePosY + g->mTransY;

	SexyMatrix3 aTransform;
	aTransform.m00 = theScaleX;
	aTransform.m10 = 0.0f;
	aTransform.m20 = 0.0f;
	aTransform.m01 = 0.0f;
	aTransform.m11 = theScaleY;
	aTransform.m21 = 0.0f;
	aTransform.m02 = aTransX;
	aTransform.m12 = aTransY;
	aTransform.m22 = 1.0f;

	const Color& aColor = g->mColorizeImages ? g->mColor : Color::White;
	PvzpBltMatrix(g, theImage, aTransform, g->mClipRect, aColor, g->mDrawMode, aSrcRect);
}

void PvzpDrawImageCenterScaledF(Graphics* g, Image* theImage, float thePosX, float thePosY, float theScaleX, float theScaleY)
{
	if (!theImage)
		return;

	if (theScaleX == 1.0f && theScaleY == 1.0f)
	{
		g->DrawImageF(theImage, thePosX, thePosY);
		return;
	}

	Rect aSrcRect(0, 0, theImage->mWidth, theImage->mHeight);
	float aTransX = theImage->mWidth * 0.5f + thePosX + g->mTransX;
	float aTransY = theImage->mHeight * 0.5f + thePosY + g->mTransY;

	SexyMatrix3 aTransform;
	aTransform.m00 = theScaleX;
	aTransform.m10 = 0.0f;
	aTransform.m20 = 0.0f;
	aTransform.m01 = 0.0f;
	aTransform.m11 = theScaleY;
	aTransform.m21 = 0.0f;
	aTransform.m02 = aTransX;
	aTransform.m12 = aTransY;
	aTransform.m22 = 1.0f;

	const Color& aColor = g->mColorizeImages ? g->mColor : Color::White;
	PvzpBltMatrix(g, theImage, aTransform, g->mClipRect, aColor, g->mDrawMode, aSrcRect);
}

void PvzpDrawFastShadow(Graphics* g, Image* theImage, float thePosX, float thePosY, float theScaleX, float theScaleY)
{
	if (!theImage || theScaleX <= 0.0f || theScaleY <= 0.0f || !g->mDestImage)
		return;

	int aCelWidth = theImage->mWidth;
	int aCelHeight = theImage->mHeight;
	int aDestW = FloatRoundToInt(theScaleX * aCelWidth);
	int aDestH = FloatRoundToInt(theScaleY * aCelHeight);
	int aDestX = FloatRoundToInt(thePosX + aCelWidth * 0.5f - aDestW * 0.5f) + g->mTransX;
	int aDestY = FloatRoundToInt(thePosY + aCelHeight * 0.5f - aDestH * 0.5f) + g->mTransY;

	Rect aDestRect(aDestX, aDestY, aDestW, aDestH);
	Rect aClip = aDestRect.Intersection(g->mClipRect);
	if (g->mDestImage)
	{
		aClip = aClip.Intersection(Rect(0, 0, g->mDestImage->mWidth, g->mDestImage->mHeight));
	}
	if (aClip.mWidth <= 0 || aClip.mHeight <= 0)
		return;

	MemoryImage* aDstImage = dynamic_cast<MemoryImage*>(g->mDestImage);
	MemoryImage* aSrcImage = dynamic_cast<MemoryImage*>(theImage);
	if (!aDstImage || !aSrcImage)
	{
		PvzpDrawImageCenterScaledF(g, theImage, thePosX, thePosY, theScaleX, theScaleY);
		return;
	}

	uint32_t* pDstBits = aDstImage->GetBits();
	uint32_t* pSrcBits = aSrcImage->GetBits();
	if (!pDstBits || !pSrcBits)
	{
		PvzpDrawImageCenterScaledF(g, theImage, thePosX, thePosY, theScaleX, theScaleY);
		return;
	}

	int dstPitch = g->mDestImage->mWidth;
	int srcPitch = theImage->mWidth;
	int srcHeight = theImage->mHeight;

	for (int y = aClip.mY; y < aClip.mY + aClip.mHeight; ++y)
	{
		int sy = ((y - aDestRect.mY) * srcHeight) / aDestH;
		if (sy < 0) sy = 0;
		else if (sy >= srcHeight) sy = srcHeight - 1;

		uint32_t* dstRow = pDstBits + y * dstPitch;
		const uint32_t* srcRow = pSrcBits + sy * srcPitch;

		for (int x = aClip.mX; x < aClip.mX + aClip.mWidth; ++x)
		{
			int sx = ((x - aDestRect.mX) * aCelWidth) / aDestW;
			if (sx < 0) sx = 0;
			else if (sx >= aCelWidth) sx = aCelWidth - 1;

			uint32_t a = srcRow[sx] >> 24;
			if (a <= 8)
				continue;

			uint32_t inv_a = 256 - a;
			uint32_t p = dstRow[x];
			uint32_t rb = (((p & 0x00FF00FF) * inv_a) >> 8) & 0x00FF00FF;
			uint32_t g_val = (((p & 0x0000FF00) * inv_a) >> 8) & 0x0000FF00;
			dstRow[x] = 0xFF000000 | rb | g_val;
		}
	}
	aDstImage->BitsChanged();
}

uint32_t AverageNearByPixels(MemoryImage* theImage, uint32_t* thePixel, int x, int y)
{
	int aRed = 0;
	int aGreen = 0;
	int aBlue = 0;
	int aBitsCount = 0;

	for (int i = -1; i <= 1; i++)
	{
		if (i == 0)
		{
			continue;
		}

		for (int j = -1; j <= 1; j++)
		{
			if ((x != 0 || j != -1) && (x != theImage->mWidth - 1 || j != 1) && (y != 0 || i != -1) && (y != theImage->mHeight - 1 || i != 1))
			{
				uint32_t aPixel = *(thePixel + i * theImage->mWidth + j);
				if (aPixel & 0xFF000000UL)  // pixel is not transparent
				{
					aRed += (aPixel >> 16) & 0x000000FFUL;
					aGreen += (aPixel >> 8) & 0x000000FFUL;
					aBlue += aPixel & 0x000000FFUL;
					aBitsCount++;
				}
			}
		}
	}

	if (aBitsCount == 0)
		return 0;

	aRed /= aBitsCount;
	aRed = std::min(aRed, 255);
	aGreen /= aBitsCount;
	aGreen = std::min(aGreen, 255);
	aBlue /= aBitsCount;
	aBlue = std::min(aBlue, 255);
	return (aRed << 16) | (aGreen << 8) | (aBlue);
}

void FixPixelsOnAlphaEdgeForBlending(Image* theImage)
{
	if (!gSexyAppBase || !gSexyAppBase->Is3DAccelerated() || !theImage)
		return;

	MemoryImage* aImage = (MemoryImage*)theImage;
	if (aImage->mPixelFormat != 0)
		return;

	aImage->CommitBits();  // populate mHasTrans and mHasAlpha
	if (!aImage->mHasTrans)
		return;

	uint32_t* aBitsPtr = aImage->GetBits();
	PerfTimer aTimer;
	aTimer.Start();

	for (int y = 0; y < theImage->mHeight; y++)
	{
		for (int x = 0; x < theImage->mWidth; x++)
		{
			if ((*aBitsPtr & 0xFF000000UL) == 0)  // pixel is fully transparent
			{
				*aBitsPtr = AverageNearByPixels(aImage, aBitsPtr, x, y);
			}

			aBitsPtr++;
		}
	}
	aImage->mBitsChangedCount++;

	int aDuration = std::max(aTimer.GetDuration(), 0.0);
	if (aDuration > 20)
	{
		PvzpLogLn("LOADING:Long sanding '{}' {} ms on {}", theImage->mFilePath, aDuration, LawnGetCurrentLevelName());
	}

	aImage->mFilePath.clear();
}

void SexyMatrix3Transpose(const SexyMatrix3& m, SexyMatrix3 &r)
{
	SexyMatrix3 temp;
	temp.m00 = m.m00;
	temp.m01 = m.m10;
	temp.m02 = m.m20;
	temp.m10 = m.m01;
	temp.m11 = m.m11;
	temp.m12 = m.m21;
	temp.m20 = m.m02;
	temp.m21 = m.m12;
	temp.m22 = m.m22;

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			r.m[i][j] = temp.m[i][j];
		}
	}
}

void SexyMatrix3InverseAffine2D(const SexyMatrix3& m, SexyMatrix3& r)
{
	float aDet = m.m00 * m.m11 - m.m01 * m.m10;
	if (std::abs(aDet) < 1e-6f)
	{
		r.LoadIdentity();
		return;
	}
	float aInvDet = 1.0f / aDet;

	r.m00 = m.m11 * aInvDet;
	r.m01 = -m.m01 * aInvDet;
	r.m02 = (m.m01 * m.m12 - m.m11 * m.m02) * aInvDet;

	r.m10 = -m.m10 * aInvDet;
	r.m11 = m.m00 * aInvDet;
	r.m12 = (m.m10 * m.m02 - m.m00 * m.m12) * aInvDet;

	r.m20 = 0.0f;
	r.m21 = 0.0f;
	r.m22 = 1.0f;
}

void SexyMatrix3Inverse(const SexyMatrix3& m, SexyMatrix3 &r)
{
	if (m.m20 == 0.0f && m.m21 == 0.0f && m.m22 == 1.0f)
	{
		SexyMatrix3InverseAffine2D(m, r);
		return;
	}

	float aDet = (m.m22 * m.m11 - m.m21 * m.m12) * m.m00- (m.m22 * m.m10 - m.m20 * m.m12) * m.m01 + (m.m21 * m.m10 - m.m20 * m.m11) * m.m02;
	float aInvDet = 1.0f / aDet;

	SexyMatrix3 temp;
	temp.m00 = (m.m22 * m.m11 - m.m21 * m.m12) * aInvDet;
	temp.m01 = (m.m02 * m.m21 - m.m22 * m.m01) * aInvDet;
	temp.m02 = (m.m12 * m.m01 - m.m02 * m.m11) * aInvDet;
	temp.m10 = (m.m20 * m.m12 - m.m22 * m.m10) * aInvDet;
	temp.m11 = (m.m00 * m.m22 - m.m02 * m.m20) * aInvDet;
	temp.m12 = (m.m02 * m.m10 - m.m12 * m.m00) * aInvDet;
	temp.m20 = (m.m21 * m.m10 - m.m20 * m.m11) * aInvDet;
	temp.m21 = (m.m20 * m.m01 - m.m21 * m.m00) * aInvDet;
	temp.m22 = (m.m00 * m.m11 - m.m10 * m.m01) * aInvDet;

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			r.m[i][j] = temp.m[i][j];
		}
	}
}

void SexyMatrix3Multiply(SexyMatrix3& m, const SexyMatrix3& l, const SexyMatrix3& r)
{
	m = l * r;
}

Color GetFlashingColor(uint32_t theCounter, int theFlashTime)
{
	int aTimeAge = static_cast<int>(theCounter % static_cast<uint32_t>(theFlashTime));
	int aTimeInf = theFlashTime / 2;
	//int aTimeDel = abs(aTimeInf - aTimeAge) / aTimeInf;
	int aGrayness = std::clamp(200 * abs(aTimeInf - aTimeAge) / aTimeInf + 55, 0, 255);
	//int aGrayness = std::clamp(55 + 200 * abs(aTimeInf - aTimeAge)/ aTimeInf, 0, 255);
	return Color(aGrayness, aGrayness, aGrayness, 255);
}

Color ColorAdd(const Color& theColor1, const Color& theColor2)
{
	int r = theColor1.mRed + theColor2.mRed;
	int g = theColor1.mGreen + theColor2.mGreen;
	int b = theColor1.mBlue + theColor2.mBlue;
	int a = theColor1.mAlpha + theColor2.mAlpha;

	return Color(std::clamp(r, 0, 255), std::clamp(g, 0, 255), std::clamp(b, 0, 255), std::clamp(a, 0, 255));  // linear dodge
}

int ColorComponentMultiply(int theColor1, int theColor2)
{
	return std::clamp(theColor1 * theColor2 / 255, 0, 255);  // multiply
}

Color ColorsMultiply(const Color& theColor1, const Color& theColor2)
{
	return Color(
		ColorComponentMultiply(theColor1.mRed, theColor2.mRed),
		ColorComponentMultiply(theColor1.mGreen, theColor2.mGreen),
		ColorComponentMultiply(theColor1.mBlue, theColor2.mBlue),
		ColorComponentMultiply(theColor1.mAlpha, theColor2.mAlpha)
	);  // multiply
}

bool PvzpLoadResources(const std::string& theGroup)
{
	return static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->PvzpLoadResources(theGroup);
}

bool PvzpResourceManager::PvzpLoadResources(const std::string& theGroup)
{
	if (IsGroupLoaded(theGroup))
	{
		mLoadedGroupRefs[theGroup]++;
		return true;
	}

	PerfTimer aTimer;
	aTimer.Start();

	StartLoadResources(theGroup);
	while (!gSexyAppBase->mShutdown && PvzpLoadNextResource());
	if (gSexyAppBase->mShutdown)
		return false;

	if (HadError())
	{
		gSexyAppBase->ShowResourceError(true);
		return false;
	}

	if (gExtractResourcesByName && !gExtractResourcesByName(this, theGroup.c_str()))
	{
		gSexyAppBase->ShowResourceError(true);
		return false;
	}

	mLoadedGroups.insert(theGroup);
	mLoadedGroupRefs[theGroup] = 1;

	int aDuration = std::max(aTimer.GetDuration(), 0.0);
	if (aDuration > 20)
	{
		PvzpLogLn("LOADED: '{}' {} ms on {}", theGroup, aDuration, LawnGetCurrentLevelName());
	}

	return true;
}

void PvzpAddImageToMap(SharedImageRef* theImage, const std::string& thePath)
{
	static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->AddImageToMap(theImage, thePath);
}

bool PvzpRemoveDynamicImage(Image* theImage)
{
	if (!gSexyAppBase || !gSexyAppBase->mResourceManager)
		return false;
	return static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->RemoveDynamicImage(theImage);
}

void PvzpResourceManager::AddImageToMap(SharedImageRef* theImage, const std::string& thePath)
{
	PVZP_ASSERT(mImageMap.find(thePath) == mImageMap.end());

	auto aImageRes = std::make_unique<ImageRes>();
	aImageRes->mImage = *theImage;
	aImageRes->mPath = thePath;
	mImageMap.insert(ResMap::value_type(thePath, std::move(aImageRes)));
}

bool PvzpResourceManager::RemoveDynamicImage(Image* theImage)
{
	bool aRemoved = false;
	auto anItr = mImageMap.begin();
	while (anItr != mImageMap.end())
	{
		ImageRes* aImageRes = (ImageRes*)anItr->second.get();
		if ((Image*)aImageRes->mImage == theImage)
		{
			if (aImageRes->mResGroup.empty())
			{
				aImageRes->DeleteResource();
				anItr = mImageMap.erase(anItr);
				aRemoved = true;
				continue;
			}
		}
		++anItr;
	}
	return aRemoved;
}

bool PvzpLoadNextResource()
{
	return static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->PvzpLoadNextResource();
}

bool PvzpResourceManager::PvzpLoadNextResource()
{
	while (mCurResGroupListItr != mCurResGroupList->end())
	{
		BaseRes* aRes = *mCurResGroupListItr;
		if (aRes->mFromProgram)
		{
			mCurResGroupListItr++;
			continue;
		}

		if (mCurResGroup == "DelayLoad_Almanac" && gLawnApp && gLawnApp->mBoard != nullptr)
		{
			if (aRes->mId == "IMAGE_ALMANAC_INDEXBACK" ||
			    aRes->mId == "IMAGE_ALMANAC_PLANTBACK" ||
			    aRes->mId == "IMAGE_ALMANAC_ZOMBIEBACK" ||
			    aRes->mId == "IMAGE_ALMANAC_PLANTCARD")
			{
				mCurResGroupListItr++;
				continue;
			}
		}

		switch (aRes->mType)
		{
		case ResType_Image:
		{
			ImageRes* anImageRes = (ImageRes*)aRes;
			if ((GLImage*)anImageRes->mImage != nullptr)
			{
				mCurResGroupListItr++;
				continue;
			}

			break;
		}

		case ResType_Sound:
		{
			SoundRes* aSoundRes = (SoundRes*)aRes;
			if (aSoundRes->mSoundId != -1)
			{
				mCurResGroupListItr++;
				continue;
			}

			break;
		}

		case ResType_Font:
		{
			FontRes* aFontRes = (FontRes*)aRes;
			if (aFontRes->mFont != nullptr)
			{
				mCurResGroupListItr++;
				continue;
			}

			break;
		}
		}

		if (!LoadNextResource())
			break;

		if (aRes->mType == ResType::ResType_Image)
		{
			ImageRes* anImageRes = (ImageRes*)aRes;
			Image* aImage = (Image*)anImageRes->mImage;
			if (aImage != nullptr)
			{
				PvzpMarkImageForSanding(aImage);
			}
		}

		return true;
	}

	return false;
}

bool PvzpFindImagePath(Image* theImage, std::string* thePath)
{
	return static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->FindImagePath(theImage, thePath);
}

bool PvzpFindFontPath(_Font* theFont, std::string* thePath) {
	return static_cast<PvzpResourceManager*>(gSexyAppBase->mResourceManager.get())->FindFontPath(theFont, thePath);
}

bool PvzpResourceManager::FindFontPath(_Font* theFont, std::string* thePath)
{
	for (auto anItr = mFontMap.begin(); anItr != mFontMap.end(); anItr++)
	{
		FontRes* aFontRes = (FontRes*)anItr->second.get();
		_Font* aFont = (_Font*)aFontRes->mFont.get();
		if (aFont == theFont)
		{
			*thePath = anItr->first;
			return true;
		}
	}
	return false;
}

bool PvzpResourceManager::FindImagePath(Image* theImage, std::string* thePath)
{
	for (auto anItr = mImageMap.begin(); anItr != mImageMap.end(); anItr++)
	{
		ImageRes* aImageRes = (ImageRes*)anItr->second.get();
		Image* aImage = (Image*)aImageRes->mImage;
		if (aImage == theImage)
		{
			*thePath = anItr->first;
			return true;
		}
	}
	return false;
}

PvzpAllocator gGlobalAllocators[MAX_GLOBAL_ALLOCATORS];
int gNumGlobalAllocators = 0;

PvzpAllocator* FindGlobalAllocator(int theSize)
{
	for (int i = 0; i < gNumGlobalAllocators; i++)
	{
		if (gGlobalAllocators[i].mItemSize == theSize)
		{
			return &gGlobalAllocators[i];
		}
	}

	PVZP_ASSERT(gNumGlobalAllocators < MAX_GLOBAL_ALLOCATORS - 1);

	PvzpAllocator* pAllocator = &gGlobalAllocators[gNumGlobalAllocators++];
	pAllocator->Initialize(16, theSize);
	return pAllocator;
}

void FreeGlobalAllocators()
{
	for (int i = 0; i < gNumGlobalAllocators; i++)
	{
		gGlobalAllocators[i].FreeAll();
	}

	gNumGlobalAllocators = 0;
}

std::string PvzpReplaceString(std::string_view theText, const char* theStringToFind, std::string_view theStringToSubstitute)
{
	std::string aFinalString(PvzpStringTranslate(theText));
	size_t aPos = aFinalString.find(theStringToFind);
	if (aPos != std::string::npos)
	{
		std::string aFinalStringToSubstitute(PvzpStringTranslate(theStringToSubstitute));
		aFinalString.replace(aPos, strlen(theStringToFind), aFinalStringToSubstitute);
	}

	return aFinalString;
}

std::string PvzpReplaceNumberString(std::string_view theText, const char* theStringToFind, int theNumber)
{
	std::string aFinalString(PvzpStringTranslate(theText));
	size_t aPos = aFinalString.find(theStringToFind);
	if (aPos != std::string::npos)
	{
		std::string aNumberString = std::to_string(theNumber);
		aFinalString.replace(aPos, strlen(theStringToFind), aNumberString);
	}

	return aFinalString;
}

bool PvzpIsPointInPolygon(const SexyVector2* thePolygonPoint, int theNumberPolygonPoints, const SexyVector2& theCheckPoint)
{
	PVZP_ASSERT(theNumberPolygonPoints >= 3);

	for (int i = 0; i < theNumberPolygonPoints; i++)
	{
		const SexyVector2& cur = thePolygonPoint[i];
		const SexyVector2& nex = thePolygonPoint[i == theNumberPolygonPoints - 1 ? 0 : i + 1];

		SexyVector2 u = (nex - cur).Perp();
		SexyVector2 v = theCheckPoint - cur;
		if (u.Dot(v) < 0)
			return false;
	}
	return true;
}
