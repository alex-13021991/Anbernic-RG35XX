﻿#pragma once

#include "../ActorBase.h"

namespace Jazz2::Actors::Lighting
{
	/**
		@brief Flickering light
		
		Invisible light-emitter actor placed in a level that contributes a randomly flickering light to the dynamic
		lighting layer, suitable for fire or torches. It has no sprite and disables all collisions; in addition to a
		randomly varying main light it emits several smaller sub-lights that wander around its position.
	*/
	class FlickerLight : public ActorBase
	{
		DEATH_RUNTIME_OBJECT(ActorBase);

	public:
		/** @brief Creates a new instance */
		FlickerLight();

		/** @brief Preloads all assets required by this actor */
		static void Preload(const ActorActivationDetails& details) {}

	protected:
		Task<bool> OnActivatedAsync(const ActorActivationDetails& details) override;
		void OnUpdate(float timeMult) override;
		void OnEmitLights(SmallVectorImpl<LightEmitter>& lights) override;

	private:
#ifndef DOXYGEN_GENERATING_OUTPUT
		// Doxygen 1.12.0 outputs also private structs/unions even if it shouldn't
		struct LightPart {
			Vector2f Pos;
			float Radius;
			float Phase;
		};
#endif

		static constexpr std::int32_t LightPartCount = 16;

		float _intensity;
		float _brightness;
		float _radiusNear;
		float _radiusFar;

		float _phase;
		SmallVector<LightPart, LightPartCount> _parts;
	};
}